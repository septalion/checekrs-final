﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// artwork from https://www.youtube.com/channel/UCtQPCnbIB7SP_gM1Xtv8bDQ n3k.ca//
public class Board : MonoBehaviour
{

    public Piece[,] pieces = new Piece[8, 8];
    public GameObject WhitePiecePrefab;
    public GameObject BlackPiecePrefab;
    public Vector3 boardOffset = new Vector3(0, 0, 0);
    public Vector3 MoveOffset = new Vector3(0, 0, 0);
    private Vector2 MouseOver;
    private Piece selectedPiece;
    public bool killed;
    public bool iswhiteturn;

    private List<Piece> checksecondMoves ;
    private Vector2 startMove;
    private Vector2 endPosition;
    private void GenerateBoard()
    {

        iswhiteturn = true;
        // white team
        for (int y = 0; y < 3; y += 1)
        {
            for (int x = 0; x < 8; x += 2)
            {
                if (y == 1 & x == 0)
                {
                    x = 1;
                }
                GeneratePiece(x, y);
            }
        }
        // black team
        for (int y = 5; y < 8; y += 1)
        {
            for (int x = 1; x < 8; x += 2)
            {
                if (y == 6 & x == 1)
                {
                    x = 0;
                }
                GeneratePieceB(x, y);
            }
        }
    }

    private void GeneratePiece(int x, int y)
    {

        GameObject go = Instantiate(WhitePiecePrefab);
        go.transform.SetParent(transform);
        Piece p = go.GetComponent<Piece>();
        pieces[x, y] = p;
        pieces[x, y].iswhite = true;
        pieces[x, y].isKing = false;
        MovePiece(p, x, y);
    }

    private void GeneratePieceB(int x, int y)
    {

        GameObject go = Instantiate(BlackPiecePrefab);
        go.transform.SetParent(transform);
        Piece p = go.GetComponent<Piece>();
        pieces[x, y] = p;
        pieces[x, y].isKing = false;
        MovePiece(p, x, y);
    }

    private void MovePiece(Piece p, int x, int y)
    {


        p.transform.position = ((Vector3.right * x) + (Vector3.up * y)) + boardOffset;
 
    }

    // Start is called before the first frame update
    void Start()
    {
        GenerateBoard();
    }

    // Update is called once per frame
    void Update()
    {
        
        int x = (int)MouseOver.x;
        int y = (int)MouseOver.y;
        UpdateMousePosition();
        
        
        // if it is the correct teams turn
        
        if(selectedPiece !=null)
        {
            DragPiece(selectedPiece);
        }
        if (Input.GetMouseButtonDown(0))
       {
           SelectPiece(x,y);
        }
        if(Input.GetMouseButtonUp(0))
        {
            tryMove((int)startMove.x, (int)startMove.y, x,y);
            selectedPiece = null;
        }
    }
    private void UpdateMousePosition()
    {

        if (!Camera.main)
        {
            Debug.Log("unable to find a main camera");
            return;
        }
        RaycastHit hit;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out hit) != false)
        {
           
            MouseOver.x = (int)hit.point.x - MoveOffset.x -1;
            MouseOver.y = (int)hit.point.y - MoveOffset.y -1;
            if( hit.point.x >1)
            {
                MouseOver.x += 1;
            }
            if (hit.point.y > 1)
            {
                MouseOver.y += 1;
            }
            if (hit.point.x < 0 & hit.point.x > -1)
            {
                MouseOver.x = -1;
            }
            else if (hit.point.x > 0 & hit.point.x < 1)
            {
                MouseOver.x = 0;
            }
            if (hit.point.y < 0 & hit.point.y > -1)
            {
                MouseOver.y = -1;
            }
            else if (hit.point.y > 0 & hit.point.y < 1)
            {
                MouseOver.y = 0;
            }
        }
         else
            {

                MouseOver.x = -1;
                MouseOver.y = -1;
            }
        }
    private void DragPiece (Piece p)
    {
        if (!Camera.main)
        {
            Debug.Log("unable to find a main camera");
            return;
        }
        RaycastHit hit;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out hit) != false)
        {
            p.transform.position = hit.point + Vector3.up;
        }

    }
    private void SelectPiece(int x, int y)

    {
        
        // out of bounds check
        if(x<-4 || x> 3 || y<-4 || y>3)
        {
            startMove = Vector2.zero;
            selectedPiece = null;
            return;
        }
        Piece p = pieces[x+4, y+4];
        if (p != null && p.iswhite == iswhiteturn)
        {
            if (checksecondMoves!=null && checksecondMoves.Count > 0)
            {
                if (checksecondMoves.Find(fp => fp == p) == null)
                {
                    selectedPiece = p;
                    startMove = MouseOver;
                    checksecondMoves.Clear();
                    return;

                }
            }
                selectedPiece = p;
                startMove = MouseOver;
                Debug.Log(selectedPiece.name + startMove);
            }
        }
    private void tryMove(int x1, int y1, int x2, int y2)
    {
        // for multiplayer  
               if(checksecondMoves !=null)
        { checksecondMoves.Clear();
        }
        killed = false;
            selectedPiece = pieces[x1 + 4, y1 + 4];
        // checks to see if the move is on the board
        if(selectedPiece == null)
        {
            startMove = Vector2.zero;
            selectedPiece = null;
            return;
        }
                
        if (selectedPiece !=null)
        {
            
            //checks to see if piece actualy moved
            if (x2 == startMove.x && y2 == startMove.y)
            {
                MovePiece(selectedPiece, x1, y1);
            }
        }
      
       
        // checks to see if the move made was valid
        if(iswhiteturn != selectedPiece.iswhite)
        {
            x1 += 4;
            y1 += 4;
            Debug.Log(x1 + " " + y1);
            MovePiece(selectedPiece, x1, y1);
            startMove = Vector2.zero;
            selectedPiece = null;
            Debug.Log("it is not your turn");
            return; }
        
        if (selectedPiece.ValidMove(pieces, x1, y1, x2, y2, selectedPiece) == true)
        {
            // checks to see if a piece was taken if jumped
            if (Mathf.Abs(x2 - x1) == 2)
            {

                Piece p = pieces[((x1 + 4) + (x2 + 4)) / 2, ((y1 + 4) + (y2 + 4)) / 2];
                if (p != null)
                {
                    pieces[((x1 + 4) + (x2 + 4)) / 2, ((y1 + 4) + (y2 + 4)) / 2] = null;
                    killed = true;
                    Destroy(p.gameObject);
                }
            }
            pieces[x2 + 4, y2 + 4] = selectedPiece;
            pieces[x1 + 4, y1 + 4] = null;
            MovePiece(selectedPiece, x2, y2);
            if (killed == true)
            {
                checkForOtherMoves(selectedPiece, x2, y2);
                EndTurn(selectedPiece);
            }
        }
        else {
            x1 += 4;
            y1 += 4;
            Debug.Log(x1+ " " + y1);
            MovePiece(selectedPiece, x1, y1);
            startMove = Vector2.zero;
            selectedPiece = null;
            return;
        }
        if (x2 < -4 || x2 > 3 || y2 < -4 || y2 > 3)
        {
            if(selectedPiece != null)
            {
                MovePiece(selectedPiece, x1,y1);
            }
            startMove = Vector2.zero;
            selectedPiece = null;
            return;
        }
        
        Debug.Log(iswhiteturn);
        x2 = x2 - (int)boardOffset.x +1;
        y2 = y2 - (int)boardOffset.y +1;
        pieces[x2, y2] = selectedPiece;
        MovePiece(selectedPiece, x2, y2);
        pieces[x1 + 4, y1 + 4] = null;
        CheckIfKing(x2 , y2 );
        EndTurn(selectedPiece);
        return;

    }
private List<Piece> checkForOtherMoves( Piece selectedPiece, int x, int y)
    {

        checksecondMoves = new List<Piece>();
        Debug.Log(pieces[x + 4, y + 4]);
        Debug.Log(killed);
                if (pieces[x+4, y+4] != null && pieces[x+4, y+4].iswhite == iswhiteturn && killed == true)
                {
                    if (selectedPiece.secondMove(pieces, x , y))
                    { checksecondMoves.Add(pieces[x+4, y+4]); }
                }
        CheckIfKing(x, y);
        Debug.Log(killed);
        Debug.Log(checksecondMoves.Count);
      

        return checksecondMoves;
    }
            


            
    private void EndTurn( Piece selectedPiece)
    
    {

        if (checksecondMoves != null && checksecondMoves.Count != 0)
        {
           
            iswhiteturn = selectedPiece.iswhite;
            checkforWin();
        }
        else
        {

            iswhiteturn = !selectedPiece.iswhite;
                checkforWin(); 
        }
        
    }
    private void checkforWin()
    {
        int WhiteTeam = 0;
        int BlackTeam = 0; 
        for (int i=0; i< 8; ++i)
        {
            for (int j=0; j<8; j++)
            {
                if (pieces[i, j] != null)
                {
                    if (pieces[i, j].iswhite == true)
                    { WhiteTeam += 1; }
                    else if (pieces[i, j].iswhite == false)
                    {
                        BlackTeam += 1;
                    }
                }
            }
        }
        if(BlackTeam == 0)
        {
            Debug.Log("white team wins");
            for (int i = 0; i < 8; ++i)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (pieces[i, j] != null)
                    {
                        Piece p = pieces[i, j];
                        Destroy(p.gameObject);
                    }
                }
            }
            GenerateBoard();
        }
        else if(WhiteTeam == 0)
        {
            Debug.Log("black Team wins");
            for (int i = 0; i < 8; ++i)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (pieces[i, j] != null)
                    {
                        Piece p = pieces[i, j];
                        Destroy(p.gameObject);
                    }
                }
            }
            GenerateBoard();
        }
        Debug.Log("black pieces remaining:" + BlackTeam + "white pieces remainging:" + WhiteTeam);
        return;
    }

    private void CheckIfKing(int x, int y)
    {
        Debug.Log("y is =" + y);
        Debug.Log(selectedPiece.isKing);
        // checks to see if position is at the end of the board and checks if the piece is king or not
        if (!selectedPiece.iswhite && !selectedPiece.isKing && (y) == 0)
        {
            Debug.Log("black king" + y);
            selectedPiece.isKing = true;// promotes it to king
            selectedPiece.transform.Rotate(Vector3.forward * 180);// changes the direction 

        }
        else if (selectedPiece.iswhite && !selectedPiece.isKing && (y) == 7)
        {
            Debug.Log("white king" + y);
            selectedPiece.isKing = true;// promotes it to king
            selectedPiece.transform.Rotate(Vector3.forward * 180);// changes the direction 
        }
        else
        {
            selectedPiece.isKing = true;
        }


    }

}

