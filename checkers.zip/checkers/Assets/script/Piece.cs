﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Piece : MonoBehaviour
{
    // Start is called before the first frame update
    public bool iswhite;

    public bool isKing;
    public bool secondMove(Piece[,] Board, int x, int y)
    {
        Debug.Log((x+4) + " " + (y+4));

        if (iswhite || isKing)
        {
            if ((x+4) >= 2 && (y+4) <= 5    )
            {
                Piece p = Board[(x + 4) - 1, (y + 4) + 1];
                if (p != null && p.iswhite != Board[x+4, y+4].iswhite)
                {
                    if (Board[(x + 4) - 2, (y + 4) + 2] == null)
                    {
                        return true;
                    }
                }
            }
        }
        else if (iswhite || isKing)
        {
            if ((x + 4) <= 5 && y >= 2)
            {
                Piece p = Board[(x + 4) - 1, (y + 4) + 1];
                if (p != null && p.iswhite != Board[x + 4, y + 4].iswhite)
                {
                    if (Board[(x + 4) - 2, (y + 4) + 2] == null)
                    {
                        return true;
                    }
                }
            }
        }
        else if (!iswhite || isKing)
        {
            if ((x + 4) >= 2 && y >= 2)
            {
                Piece p = Board[(x + 4) - 1, (y + 4) - 1];
                if (p != null && p.iswhite != Board[x + 4, y + 4].iswhite)
                {
                    if (Board[(x + 4) - 2, (y + 4) - 2] == null)
                    {
                        return true;
                    }
                }
            }
            else if (!iswhite || isKing)
            {
                if ((x + 4) >= 2 && (y + 4) >= 2)
                {
                    Piece p = Board[(x + 4) - 1, (y + 4) - 1];
                    if (p != null && p.iswhite != Board[x + 4, y + 4].iswhite)
                    {
                        if (Board[(x + 4) - 2, (y + 4) - 2] == null)
                        {
                            return true;
                        }
                    }
                }
            }

        }
        return false;
    }
    public bool ValidMove(Piece[,] Board, int x1, int y1, int x2, int y2, Piece selecedPiece)
    {

        // checks to see if tile is occupied
        if (Board[x2 + 4, y2 + 4] != null)
        {
            Debug.Log("tile ocupied");
            return false; }

        int movenumb = Mathf.Abs((x2) - (x1));
        int movenumby = (y2) - (y1);
       // validates movement and checks if it can or will kill a unti in that tile
        if (iswhite || isKing)
        {
            if (movenumb == 1)
            {
                if (movenumby == 1)
                {
                    Debug.Log("valid");
                    return true;
                }

            }
           else if (movenumb == 2)
            {
                if (movenumby == 2)
                {
                    Debug.Log("valid");
                    Piece P = Board[((x1+4) + (x2+4)) / 2, ((y1+4) + (y2+4)) / 2];
                    if (P != null && P.iswhite != iswhite)
                    { return true; }
                }

            }
        }
       if (!iswhite || isKing)
        {
            if (movenumb == 1)
            {
                if (movenumby == -1)
                {
                    Debug.Log("Valid");
                    return true;
                }

            }
            if (movenumb == 2)
            {
                if (movenumby == -2)
                {
                    Debug.Log("valid");
                    Piece P = Board[((x1+4) + (x2 +4)) / 2, ((y1 +4) + (y2 +4)) / 2];
                    if (P != null && P.iswhite != iswhite)
                    { return true; }
                }

            }
        }
        Debug.Log("invalid move");
        return false;
    }
}
